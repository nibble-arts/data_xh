<?php

namespace form\source;

class Mysql {

	public static function fetch ($query) {
	
		return "";
	}
}

?>