<?php

$plugin_tx['form']['forms']="Formulare";
$plugin_tx['form']['entry']="Eintrag";
$plugin_tx['form']['entries']="Einträge";
$plugin_tx['form']['none']="keine";

$plugin_tx['form']['username']="Benutzername";
$plugin_tx['form']['time']="Zeit";
$plugin_tx['form']['edit']="Eintrag bearbeiten";

$plugin_tx['form']['email_sent']="Eine Email wurde versandt";
$plugin_tx['form']['email_fail']="Fehler beim Versenden der Email";

$plugin_tx['form']['fail_noform']="Formular nicht gefunden";

$plugin_tx['form']['form_nofields']="Formdefinition enthält keine Felder";

$plugin_tx['form']['fail_formpath']="Formular-Verzeichnis nicht gefunden";
$plugin_tx['form']['fail_data_mkdir']="Formular-Verzeichnis konnte nicht erstellt werden";
$plugin_tx['form']['fail_download_mkdir']="Download-Verzeichnis konnte nicht erstellt werden";
$plugin_tx['form']['fail_fileread']="File konnte nicht gelesen werden";
$plugin_tx['form']['fail_filewrite']="Fehler beim speichern der Daten.";
$plugin_tx['form']['fail_fileexists']="File existiert schon";
$plugin_tx['form']['fail_noformat']="Das Ausgabeformat existiert nicht";

$plugin_tx['form']['data_save']="Die Daten wurden erfolgreich gespeichert.";

$plugin_tx['form']['menu_main']="Formulare";
$plugin_tx['form']['title_settings']="Abfrageeinstellungen";
$plugin_tx['form']['description_settings']="Zum Aufruf eines Formulars ist im Plugin der Name ohne Erweiterung anzugeben. Zum Format nutzen Sie die Hilfe.";

$plugin_tx['form']['back']="Zurück";
