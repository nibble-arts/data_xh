<?php

$plugin_tx['form']['forms']="Forms";
$plugin_tx['form']['entry']="Entry";
$plugin_tx['form']['entries']="Entries";
$plugin_tx['form']['none']="no";

$plugin_tx['form']['username']="Username";
$plugin_tx['form']['time']="Time";
$plugin_tx['form']['edit']="Edit entry";

$plugin_tx['form']['email_sent']="Email sent";
$plugin_tx['form']['email_fail']="Error in sending the email";

$plugin_tx['form']['fail_noform']="Form \"%s\" not found";
$plugin_tx['form']['fail_formpath']="Form directory not found";

$plugin_tx['form']['fail_data_mkdir']="Error creating the form data directory";
$plugin_tx['form']['fail_download_mkdir']="Error creating the form download directory";

$plugin_tx['form']['fail_fileread']="File \"%s\" not readable";
$plugin_tx['form']['fail_filewrite']="File write error";
$plugin_tx['form']['fail_fileexists']="File \"%s\" already exists";

$plugin_tx['form']['data_save']="Data saved";

$plugin_tx['form']['menu_main']="Forms";
$plugin_tx['form']['title_settings']="Forms settings";
$plugin_tx['form']['description_settings']="Zum Aufruf eines Formulars ist im Plugin der Name ohne Erweiterung anzugeben. Zum Format nutzen Sie die Hilfe.";

$plugin_tx['form']['back']="back";
